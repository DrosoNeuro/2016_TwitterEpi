/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TwitterParser.TweetParser;

import TwitterParser.helpers.input_type;
import java.io.FileNotFoundException;

/**
 *
 * @author toddbodnar
 */
public class settings {
    public static input_type data_type = input_type.API_TWEET;
    public static String data_location = null;

    public static int updatetime=120;
    public static String number="5555550125";
    public static boolean update = false;
    public static boolean finish = false;
    
    public static String email = "";
    public static String smpt = "";
    
}

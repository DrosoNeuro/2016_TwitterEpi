/**
 * A collection of Tweet parsers. Each TweetParser is fed a single tweet object at a time and then does -something- with it.
 * If you want to add your own TweetParser, include it in ... TODO: copy over tweetparser code
 */

package TwitterParser.TweetParser.processors;